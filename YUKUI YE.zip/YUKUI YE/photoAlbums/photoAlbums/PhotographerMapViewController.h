//
//  PhotographerMapViewController.h
//  photoAlbums
//
//  Created by Yukui Ye on 5/1/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import "MapViewController.h"

@interface PhotographerMapViewController : MapViewController
@property(nonatomic,strong) NSManagedObjectContext *managedObjectContext;

-(void)reload;

@end
