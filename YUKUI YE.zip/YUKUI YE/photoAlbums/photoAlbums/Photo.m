//
//  Photo.m
//  photoAlbums
//
//  Created by Yukui Ye on 5/1/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import "Photo.h"
#import "Photographer.h"


@implementation Photo

@dynamic imageURL;
@dynamic subtitle;
@dynamic title;
@dynamic unique;
@dynamic latitude;
@dynamic thumbnailURLString;
@dynamic longitude;
@dynamic whoTook;

@end
