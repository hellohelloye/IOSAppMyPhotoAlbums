//
//  MapViewController.h
//  photoAlbums
//
//  Created by Yukui Ye on 5/1/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MapKit/MapKit.h"
@interface MapViewController : UIViewController <MKMapViewDelegate>
@property (nonatomic,strong) IBOutlet MKMapView *mapView;

@end
