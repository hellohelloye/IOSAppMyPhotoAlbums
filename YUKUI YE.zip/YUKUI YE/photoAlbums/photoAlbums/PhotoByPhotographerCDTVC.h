//
//  PhotoByPhotographerCDTVC.h
//  photoAlbums
//
//  Created by Yukui Ye on 4/30/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import "CoreDataTableViewController.h"
#import "Photographer.h"
@interface PhotoByPhotographerCDTVC : CoreDataTableViewController

@property (strong,nonatomic) Photographer *photographer;
@end
