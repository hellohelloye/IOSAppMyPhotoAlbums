//
//  DemoPhotographerCDTVC.h
//  photoAlbums
//
//  Created by Yukui Ye on 4/30/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import "PhotographerCDTVC.h"

@interface DemoPhotographerCDTVC : PhotographerCDTVC

@end
