//
//  Photographer.m
//  photoAlbums
//
//  Created by Yukui Ye on 4/29/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import "Photographer.h"
#import "Photo.h"


@implementation Photographer

@dynamic name;
@dynamic photos;

@end
