//
//  DemoPhotographerMapViewController.h
//  photoAlbums
//
//  Created by Yukui Ye on 5/1/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import "PhotographerMapViewController.h"

@interface DemoPhotographerMapViewController : PhotographerMapViewController

@end
