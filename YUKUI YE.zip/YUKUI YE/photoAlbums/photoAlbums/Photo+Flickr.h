//
//  Photo+Flickr.h
//  photoAlbums
//
//  Created by Yukui Ye on 4/29/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import "Photo.h"

@interface Photo (Flickr)
+ (Photo *)photoWithFlickrInfo:(NSDictionary *)photoDictionary
        inManagedObjectContext:(NSManagedObjectContext *)context;

@end
