//
//  PhotoViewController.h
//  photoAlbums
//
//  Created by Yukui Ye on 5/1/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import "ImageViewController.h"
#import "Photo.h"

@interface PhotoViewController : ImageViewController
@property (nonatomic, strong) Photo *photo;

@end
