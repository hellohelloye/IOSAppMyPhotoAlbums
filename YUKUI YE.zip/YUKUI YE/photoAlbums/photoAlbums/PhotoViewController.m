//
//  PhotoViewController.m
//  photoAlbums
//
//  Created by Yukui Ye on 5/1/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import "PhotoViewController.h"

@interface PhotoViewController ()

@end

@implementation PhotoViewController 

-(void)setPhoto:(Photo *)photo
{
    _photo = photo;
    self.title = self.photo;
    self.imageURL = [[NSURL alloc] initWithString:@"http://www.flickr.com/photos/94285633@N05/8584472794/in/photostream/"];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

@end
