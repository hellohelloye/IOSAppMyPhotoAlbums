//
//  Photo+MKAnnotation.h
//  photoAlbums
//
//  Created by Yukui Ye on 5/1/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import "Photo.h"
#import <MapKit/MapKit.h>
@interface Photo (MKAnnotation)<MKAnnotation>

-(UIImage *)thumbnail;
@end
