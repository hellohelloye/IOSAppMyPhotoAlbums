//
//  LatestFlickrPhotoTVC.m
//  yyePhotoAlbums
//
//  Created by Yukui Ye on 3/23/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import "LatestFlickrPhotoTVC.h"
#import "FlickrFetcher.h"

@interface LatestFlickrPhotoTVC ()

@end

@implementation LatestFlickrPhotoTVC


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self loadLatestPhotosFromFlickr];
   // self.photos = [FlickrFetcher yyePhotos];
    [self.refreshControl addTarget:self  action:@selector(loadLatestPhotosFromFlickr)
                  forControlEvents:UIControlEventValueChanged];
   
}

-(void) loadLatestPhotosFromFlickr
{
    [self.refreshControl beginRefreshing];
    dispatch_queue_t loaderQ = dispatch_queue_create("flickr latest loader", NULL);
    dispatch_async(loaderQ, ^{
       NSArray *latestPhotos =  self.photos = [FlickrFetcher latestGeoreferencedPhotos];
        dispatch_async(loaderQ, ^{
            self.photos = latestPhotos;
            [self.refreshControl endRefreshing];
        });
    });
}


@end
