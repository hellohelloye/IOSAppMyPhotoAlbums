//
//  myFamilyPortraitViewController.m
//  yyePhotoAlbums
//
//  Created by Yukui Ye on 3/23/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import "myFamilyPortraitViewController.h"

@interface myFamilyPortraitViewController ()

@end

@implementation myFamilyPortraitViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	self.imageURL = [[NSURL alloc] initWithString:@"http://b72.photo.store.qq.com/psu?/289887743/qldH*gLHXOy46Tu8HkJJdJabaxPgoEmX7pIvlge9hfg!/b/YWQD9SpCMgAAYqvp7ioUMwAA&bo=gALgAQAAAAABAEQ!"];
}

@end
