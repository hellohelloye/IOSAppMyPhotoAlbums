//
//  main.m
//  yyePhotoAlbums
//
//  Created by Yukui Ye on 3/23/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UIViewAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([UIViewAppDelegate class]));
    }
}
