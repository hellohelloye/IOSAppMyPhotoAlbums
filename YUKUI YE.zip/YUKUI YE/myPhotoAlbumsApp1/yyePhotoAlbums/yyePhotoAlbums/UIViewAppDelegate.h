//
//  UIViewAppDelegate.h
//  yyePhotoAlbums
//
//  Created by Yukui Ye on 3/23/13.
//  Copyright (c) 2013 Yukui Ye. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
